// components/custom/custom.js
Component({
    properties: {
        // 这里定义了 headerText 属性，属性值可以在组件使用时指定
        headerText: {
            type: String,
            value: '默认标题文案',
        }
    },
    data: {
        // 组件内部数据
        defaultStates: {},
        list: [
            {
                src: 'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=304465615,2594695139&fm=26&gp=0.jpg',
                title: ' 专为贵阳人设计的游戏——多乐贵阳捉鸡麻将',
                index: "0"
            },
            {
                src: 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2517064546,2931709055&fm=26&gp=0.jpg',
                title: '山东品牌手游《多乐够级》 给你最欢乐的闲暇时光',
                index: "1"
            },
            {
                src: 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=434648423,1446376953&fm=26&gp=0.jpg',
                title: '多乐保皇火力全开 保皇还能这么玩！',
                index: "2"
            },
            {
                src: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1574755454525&di=89c6a5661ef61809f2e8167d578f9566&imgtype=jpg&src=http%3A%2F%2Fimg1.imgtn.bdimg.com%2Fit%2Fu%3D3658367596%2C1357551675%26fm%3D214%26gp%3D0.jpg',
                title: '多乐保皇一款山东特色经典扑克游戏',
                index: "3"
            },
            {
                src: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1574755435447&di=76fdd721c01ddf3093466d08e2f901ba&imgtype=0&src=http%3A%2F%2Fpic7.58cdn.com.cn%2Fzhuanzh%2Fn_v2360ae66a1c5d4ed19d322a66fd1a1d75_750_0.jpg',
                title: '时尚简约中国风的棋牌游戏——卡五星',
                index: "4"
            },
        ],
    },
    methods: {
        // 自定义方法
        customMethod: function () { },
        aa: function (e) {
            qq.navigateTo({
                url: `../xq/xq?type=1&index=${e.currentTarget.dataset.index}`,
                // url: '../xq/xq?type=1&index=' + e.currentTarget.dataset.index
            })
        }
    }
})