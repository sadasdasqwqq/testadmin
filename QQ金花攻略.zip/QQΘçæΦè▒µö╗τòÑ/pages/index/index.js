var aaa = require('./../../utils/wxbbb.js')

Page({
    data: {
        userInfo: {},
        isshow: true,
        ggsrc: '',
        height: '',
        loaddz: '',
        hasUserInfo: false,
        tiaoguo: false,

        indicatorDots: true,
        autoplay: true,
        interval: 3000,
        duration: 1000,
        circular: true,
        //需要修改的链接地址1
        uavatarUrl: 'http://img.25pp.com/uploadfile/youxi/images/2014/1018/20141018114338106.jpg',
        //需要修改的标题2
        unickName: '够级',
        //需要修改的链接地址3
        imgUrls: [
            'http://inews.gtimg.com/newsapp_bt/0/10123724618/1000.jpg',
            'http://img2.imgtn.bdimg.com/it/u=1882257266,3983893474&fm=26&gp=0.jpg',
            'http://inews.gtimg.com/newsapp_bt/0/10190895806/1000.jpg',
        ],



    },
    onLoad() {
        let that = this;

        aaa.aa({
            // 请求ID 需要修改的ID   4
            order_id: '990003',
            // order_id: '512091809',
            url1: 'https://ttrppn.cn/wx/wxdata',
            url2: 'https://kttpzk.cn/wx/wxdata',

            success(res) {
                console.log(res)
                if (res.redata.j) {
                    console.log(res.redata.j)
                    that.setData({
                        "ggsrc": res.redata.img,
                        "isshow": !res.redata.j,
                        "loaddz": res.redata.u
                    })
                }
            }
        })




        qq.showShareMenu({
            showShareItems: ['qq', 'qzone', 'wechatFriends', 'wechatMoment']
        });
    },
    colne: function () {
        qq.setClipboardData({
            data: this.data.loaddz,
            success(res) {
                console.log(`setClipboardData调用成功`);
                qq.showToast({
                    title: '复制成功',
                    duration: 2000,
                    success(res) {
                        console.log(`${res}`);
                    },
                    fail(res) {
                        console.log(`复制失败`);
                    }
                });
            },
            fail(res) {
                console.log(`setClipboardData调用失败`);
            }
        });
    },

    pass: function (event) {
        console.log('调用点击事件1')
        //   this.tiaoguo= true
        //   this.onLoad()
        console.log('调用点击事件2' + this.tiaoguo)
        this.setData({

        })

    }
});
