// components/custom/custom.js
Component({
    properties: {
        // 这里定义了 headerText 属性，属性值可以在组件使用时指定
        headerText: {
            type: String,
            value: '默认标题文案',
        }
    },
    data: {
        // 组件内部数据
        defaultStates: {},
        list: [
            {
                src: 'http://img3.imgtn.bdimg.com/it/u=1737709645,1049812238&fm=26&gp=0.jpg',
                title: '经典斗地主，地主是一方，其余两家一方，先出完的一方胜',
                index: "0"
            },
            {
                src: 'http://img4.imgtn.bdimg.com/it/u=3216862325,1328228337&fm=26&gp=0.jpg',
                title: '天地赖子斗地主就是有设定“赖子牌”，而这个设定是随机的',
                index: "1"
            },
            {
                src: 'http://img5.imgtn.bdimg.com/it/u=2980106220,1133293967&fm=26&gp=0.jpg',
                title: '不洗牌斗地主就是在上一局游戏的基础上，不洗牌开始分牌',
                index: "2"
            },
            {
                src: 'http://img5.imgtn.bdimg.com/it/u=3877211862,3186494847&fm=26&gp=0.jpg',
                title: '欢乐斗地主是腾讯移动游戏平台的首款实时对战棋牌手游',
                index: "3"
            },
            {
                src: 'https://ss2.bdstatic.com/8_V1bjqh_Q23odCf/pacific/1874199754.png',
                title: 'JJ斗地主竞技世界以比赛形式推出的一款网络棋牌游戏',
                index: "4"
            },
        ],
    },
    methods: {
        // 自定义方法
        customMethod: function () { },
        aa: function (e) {
            wx.navigateTo({
                url: `../xq/xq?type=1&index=${e.currentTarget.dataset.index}`,
                // url: '../xq/xq?type=1&index=' + e.currentTarget.dataset.index
            })
        }
    }
})