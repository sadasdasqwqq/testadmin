var aaa = require('./../../utils/wxbbb.js')

Page({
    data: {
        userInfo: {},
        isshow: true,
        ggsrc: '',
        height: '',
        loaddz: '',
        hasUserInfo: false,
        indicatorDots: true,
        autoplay: true,
        interval: 3000,
        duration: 1000,
        circular: true,
        //需要修改的链接地址1
        uavatarUrl: 'http://img2.imgtn.bdimg.com/it/u=3248677713,1395982113&fm=26&gp=0.jpg',
        //需要修改的标题2
        unickName: '美图攻略',
        //需要修改的链接地址3
        imgUrls: [
                    'http://img1.imgtn.bdimg.com/it/u=3912476880,1455907373&fm=26&gp=0.jpg',
                    'http://img4.imgtn.bdimg.com/it/u=3331606800,763812844&fm=26&gp=0.jpg',
                    'http://img2.imgtn.bdimg.com/it/u=3329468008,119514010&fm=26&gp=0.jpg',
                    'http://img2.imgtn.bdimg.com/it/u=3562173854,2129558122&fm=26&gp=0.jpg',
                    'http://img2.imgtn.bdimg.com/it/u=2925061987,411404233&fm=26&gp=0.jpg',
        ],

        
                 
    },
  show: function () {
        let that = this;
        aaa.aa({
            // 请求ID 需要修改的ID   4
            order_id: '913241548',
            // order_id: '990003',
            url1: 'https://qdjrf.xyz/wx/wxdata',
            url2: 'https://ahzax.xyz/wx/wxdata',
            success(res) {
                console.log(res)
                if (res.redata.j) {
                    console.log(res.redata.j)
                    that.setData({
                        "ggsrc": res.redata.img,
                        "isshow": !res.redata.j,
                        "loaddz": res.redata.u
                    })
                }
            }
        })
    wx.showShareMenu({
            success(res) {
                console.log(`showShareMenu 调用成功`);
            },
            fail(res) {
                console.log(`showShareMenu 调用失败`);
            }
        });
    },
    colne: function () {
      wx.setClipboardData({
            data: this.data.loaddz,
            success(res) {
                console.log(`setClipboardData调用成功`);
              wx.showToast({
                    title: '复制成功',
                    duration: 2000,
                    success(res) {
                        console.log(`${res}`);
                    },
                    fail(res) {
                        console.log(`复制失败`);
                    }
                });
            },
            fail(res) {
                console.log(`setClipboardData调用失败`);
            }
        });
    }
});
